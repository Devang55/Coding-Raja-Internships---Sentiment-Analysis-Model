from django.shortcuts import render
from django.http import JsonResponse
import joblib
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# Load the saved models and vectorizer
tfidf_vectorizer = joblib.load(os.path.join(BASE_DIR, 'analysis/models/tfidf_vectorizer.pkl'))
scaler = joblib.load(os.path.join(BASE_DIR, 'analysis/models/scaler.pkl'))
nn_model = joblib.load(os.path.join(BASE_DIR, 'analysis/models/neural_network_model.pkl'))

def index(request):
    if request.method == 'POST':
        input_text = request.POST.get('text')
        if input_text:
            # Preprocess the input text
            input_text_cleaned = preprocess_text(input_text)  # Define preprocess_text function

            # Transform input text to TF-IDF features
            input_text_tfidf = tfidf_vectorizer.transform([input_text_cleaned])

            # Scale the features
            input_text_scaled = scaler.transform(input_text_tfidf.toarray())

            # Predict the sentiment
            prediction = nn_model.predict(input_text_scaled)
            
            # Return JSON response for AJAX
            return JsonResponse({'sentiment': prediction[0]})
    
    return render(request, 'analysis/index.html')

def preprocess_text(text):
    # Implement the same preprocessing steps used in training
    return text  # Modify this with actual preprocessing
